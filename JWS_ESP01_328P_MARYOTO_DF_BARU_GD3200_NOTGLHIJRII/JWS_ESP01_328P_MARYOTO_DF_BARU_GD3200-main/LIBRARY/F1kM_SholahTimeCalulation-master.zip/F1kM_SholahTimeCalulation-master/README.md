# Sholah Time Calculation

Sholah Time Calculation Library for Arduino IDE (C++)
calculate sholah time using location coordinat and Date

by Fk1M (For 1000 Masjid / Untuk 1000 Masjid) 
https://www.facebook.com/groups/761058907424496/
